

const items =[{
  id:`1`,
  item_image:`image/item1.jpg`,
  rating:{
    stars:4.4,
    noofReviews:1400,
  },
  company_name:`carton London`,
  item_name:`classfull video`,
  current_price:534,
  original_price:4343,
  discount:32,

},{
  id:`2`,
  item_image:`image/item2.jpg`,
  rating:{
    stars:4.4,
    noofReviews:1400,
  },
  company_name:`carton London`,
  item_name:`classfull video`,
  current_price:534,
  original_price:4343,
  discount:32,

},{
  id:`3`,
  item_image:`image/item3.jpg`,
  rating:{
    stars:4.4,
    noofReviews:1400,
  },
  company_name:`carton London`,
  item_name:`classfull video`,
  current_price:534,
  original_price:4343,
  discount:32,

},{
  id:`4`,
  item_image:`image/item4.jpg`,
  rating:{
    stars:4.4,
    noofReviews:1400,
  },
  company_name:`carton London`,
  item_name:`classfull video`,
  current_price:534,
  original_price:4343,
  discount:32,

},{
  id:`5`,
  item_image:`image/item5.jpg`,
  rating:{
    stars:4.4,
    noofReviews:1400,
  },
  company_name:`carton London`,
  item_name:`classfull video`,
  current_price:5000000,
  original_price:4344300000,
  discount:32,

},{
  id:`6`,
  item_image:`image/item6.jpg`,
  rating:{
    stars:4.4,
    noofReviews:1400,
  },
  company_name:`carton London`,
  item_name:`classfull video`,
  current_price:534,
  original_price:4343,
  discount:32,

},{
  id:`7`,
  item_image:`image/item7.jpg`,
  rating:{
    stars:4.4,
    noofReviews:1400,
  },
  company_name:`carton London`,
  item_name:`classfull video`,
  current_price:534,
  original_price:4343,
  discount:32,

},{
  id:`8`,
  item_image:`image/item8.jpg`,
  rating:{
    stars:4.4,
    noofReviews:1400,
  },
  company_name:`carton London`,
  item_name:`classfull video`,
  current_price:534,
  original_price:4343,
  discount:32,

},{
  id:`9`,
  item_image:`image/item9.jpg`,
  rating:{
    stars:4.4,
    noofReviews:1400,
  },
  company_name:`carton London`,
  item_name:`classfull video`,
  current_price:534,
  original_price:4343,
  discount:32,

},
{
  id:`10`,
  item_image:`image/item10.jpg`,
  rating:{
    stars:4.4,
    noofReviews:1400,
  },
  company_name:`carton London`,
  item_name:`classfull video`,
  current_price:534,
  original_price:4343,
  discount:32,

},
]  