

let bagitemobjects;
let bagitemstr =localStorage.getItem(`bagitem`);
bagitem= bagitemstr? JSON.parse(bagitemstr):[];
onclick();

function onclick() {
    loadbagitem();
    displaybagitem();
    
}

function loadbagitem() {
    bagitemobjects=bagitem.map(itemid => {
        for (let i=0;i<items.length;i++){
            if(itemid==items[i].id){
                return items[i];
            }
        }
    });
    console.log(bagitemobjects);
}

function displaybagitem() {
   
    let containercarts =document.querySelector(`.bag_items_container`);
    containercarts.innerHTML =` <div class="bag_item_container">
    <div class="item_left_part">
        <img class="bag_item_image" src="image/item1.jpg" alt="">
    </div>
    <div class="item_right_part">
        <div class="company">addidas</div>
        <div class="item_name">polo colar</div>
        <div class="price_container">
            <span class="current_price">Rs 980</span>
            <span class="original_price">Rs 3434</span>
            <span class="discount">(0% OFF)</span>
        </div>
        <div class="return_period">
            <span class="return_period_days">14 days</span>
            return availble
        </div>
        <div class="delovery_detail">delivery by
            <span class="delivery_details_days">10-oct-23</span>
        </div>

    </div>
    <div class="remove_from_carts">x</div>
</div>`
}

function  janrethtml(item) {


}