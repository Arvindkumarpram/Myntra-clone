let bagitem ;
onload();
function onload() {
  let bagitemstr =localStorage.getItem(`bagitem`);
  bagitem= bagitemstr? JSON.parse(bagitemstr):[];
  displayitemsonhomepage();
 bagitemcount();
}



function addtobag(itemid) {
bagitem.push(itemid);
localStorage.setItem(`bagitem`,JSON.stringify(bagitem));
bagitemcount();

}






function bagitemcount() {
  let bagcount =document.querySelector(`.bag_item_count`);
  bagcount.innerText = bagitem.length;
}






function displayitemsonhomepage() {
  let itemcontainerElement =document.querySelector(`.container`);
  if(!itemcontainerElement){
    return;
  }
let innerHTML =``;

items.forEach(item => {
    innerHTML += ` 
 <div class="items" >
   <img src="${item.item_image}" class="item_image" controls ></img>
   <div class="rating">${item.rating.stars} | ${item.rating.noofReviews}  </div>
   <div class="company_name">${item.company_name}</div>
   <div class="item_name">${item.item_name} </div>
   <div class="price">
   <span class="current_price">Rs ${item.current_price}</span>
   <span class="original_price">Rs ${item.original_price}</span>
   <span class="discount">(${item.discount}% OFF)</span>
   </div>
   <button class="btn_add_bag" onclick="addtobag(${item.id})">Add to btn</button>
 </div> `  
});
itemcontainerElement.innerHTML = innerHTML;
}

// function collectitem() {
//   let itemcollect =document.querySelector(`.collecteditem`);
//   itemcollect.innerHTML = displayitemsonhomepage();
// }

